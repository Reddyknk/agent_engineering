"""A parent agent that delegates travel work to two specialist agents."""

from __future__ import annotations

from google.adk.agents import Agent
from google.adk.apps import App
from google.adk.models import Gemini
from google.adk.tools.tool_context import ToolContext
from google.genai import types

from adk_multiagent_systems.shared import (
    MODEL_NAME,
    RETRY_OPTIONS,
    Graceful429Plugin,
    log_model_response,
    log_query_to_model,
)


def save_attractions_to_state(
    tool_context: ToolContext,
    country: str,
    attractions: list[str],
) -> dict[str, object]:
    """Persist the selected country and attraction list in session state."""
    cleaned = [item.strip() for item in attractions if item.strip()]
    tool_context.state["country"] = country.strip()
    tool_context.state["attractions"] = cleaned
    return {
        "status": "success",
        "country": tool_context.state["country"],
        "attractions": cleaned,
    }


def build_model() -> Gemini:
    return Gemini(model=MODEL_NAME, retry_options=RETRY_OPTIONS)


travel_brainstormer = Agent(
    name="travel_brainstormer",
    model=build_model(),
    description="Helps a traveler choose a country based on their priorities.",
    instruction="""
Ask about the traveler's priorities: adventure, leisure, learning, shopping,
food, or art. Recommend two or three countries and briefly explain each match.
When the user chooses a country, transfer back to the steering agent.
""",
    before_model_callback=log_query_to_model,
    after_model_callback=log_model_response,
)

attractions_planner = Agent(
    name="attractions_planner",
    model=build_model(),
    description="Builds a focused attraction list for a selected country.",
    instruction="""
Identify five to seven attractions for the user's selected country. Balance
major sights with one or two less obvious experiences. Call
save_attractions_to_state with the country and final list. If state already
contains attractions, use them to refine the answer.

Saved attractions: {attractions?}
""",
    tools=[save_attractions_to_state],
    before_model_callback=log_query_to_model,
    after_model_callback=log_model_response,
)

root_agent = Agent(
    name="steering",
    model=build_model(),
    description="Routes a traveler to the right specialist.",
    instruction="""
Welcome the traveler. If they do not know where to go, transfer to
travel_brainstormer. If they name a country, transfer to attractions_planner.
After a specialist finishes, summarize the decision and suggest one next step.
""",
    sub_agents=[travel_brainstormer, attractions_planner],
    generate_content_config=types.GenerateContentConfig(temperature=0),
)

quota_plugin = Graceful429Plugin(
    name="graceful_429_plugin",
    fallback_text={
        "default": (
            "The model quota is temporarily exhausted. Wait briefly, then retry "
            "the last travel request."
        )
    },
)

app = App(
    name="parent_and_subagents",
    root_agent=root_agent,
    plugins=[quota_plugin],
)

