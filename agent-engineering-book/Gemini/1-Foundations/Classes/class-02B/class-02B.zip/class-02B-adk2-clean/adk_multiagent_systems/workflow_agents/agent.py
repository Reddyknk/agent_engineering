"""A composed ADK workflow: sequential -> loop -> parallel -> file output."""

from __future__ import annotations

import logging
import os
import re
from pathlib import Path

from google.adk.agents import Agent, LoopAgent, ParallelAgent, SequentialAgent
from google.adk.apps import App
from google.adk.integrations.langchain import LangchainTool
from google.adk.models import Gemini
from google.adk.tools import exit_loop
from google.adk.tools.tool_context import ToolContext
from google.genai import types
from langchain_community.tools import WikipediaQueryRun
from langchain_community.utilities import WikipediaAPIWrapper

from adk_multiagent_systems.shared import (
    MODEL_NAME,
    PROJECT_ROOT,
    RETRY_OPTIONS,
    Graceful429Plugin,
    log_model_response,
    log_query_to_model,
)

LOGGER = logging.getLogger(__name__)
OUTPUT_DIR = PROJECT_ROOT / "movie_pitches"


def build_model() -> Gemini:
    return Gemini(model=MODEL_NAME, retry_options=RETRY_OPTIONS)


def append_to_state(
    tool_context: ToolContext,
    field: str,
    response: str,
) -> dict[str, str]:
    """Append an agent's text to a list stored under a session-state key."""
    existing = tool_context.state.get(field, [])
    if not isinstance(existing, list):
        existing = [str(existing)]
    tool_context.state[field] = [*existing, response]
    LOGGER.info("Added an item to state key %s", field)
    return {"status": "success"}


def write_movie_pitch(filename: str, content: str) -> dict[str, str]:
    """Write a text pitch inside the project's fixed movie_pitches directory."""
    stem = Path(filename).stem
    safe_stem = re.sub(r"[^A-Za-z0-9._-]+", "_", stem).strip("._")
    safe_stem = safe_stem or "movie_pitch"
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    target = OUTPUT_DIR / f"{safe_stem}.txt"
    target.write_text(content, encoding="utf-8")
    return {
        "status": "success",
        "path": str(target.relative_to(PROJECT_ROOT)),
    }


researcher = Agent(
    name="researcher",
    model=build_model(),
    description="Researches the historical subject and fills factual gaps.",
    instruction="""
Research the historical figure in {PROMPT?}. Use Wikipedia to gather reliable
dates, achievements, conflicts, and context. If a draft and critical feedback
already exist, focus on the requested gaps. Call append_to_state with field
'RESEARCH' and a concise fact brief.

Current draft: {PLOT_OUTLINE?}
Critical feedback: {CRITICAL_FEEDBACK?}
""",
    tools=[
        LangchainTool(
            tool=WikipediaQueryRun(
                api_wrapper=WikipediaAPIWrapper(),
                handle_tool_error=True,
            )
        ),
        append_to_state,
    ],
    before_model_callback=log_query_to_model,
    after_model_callback=log_model_response,
)

screenwriter = Agent(
    name="screenwriter",
    model=build_model(),
    description="Writes and revises a film logline and three-act outline.",
    instruction="""
Create or improve an inspiring, historically grounded movie pitch about
{PROMPT?}. Use RESEARCH and address CRITICAL_FEEDBACK. Call append_to_state
with field 'PLOT_OUTLINE' and include a logline plus a clear three-act outline.

Research: {RESEARCH?}
Earlier drafts: {PLOT_OUTLINE?}
Critical feedback: {CRITICAL_FEEDBACK?}
""",
    tools=[append_to_state],
    generate_content_config=types.GenerateContentConfig(temperature=0.3),
    before_model_callback=log_query_to_model,
    after_model_callback=log_model_response,
)

critic = Agent(
    name="critic",
    model=build_model(),
    description="Checks the pitch and decides whether another writing pass is needed.",
    instruction="""
Review the newest PLOT_OUTLINE for historical coherence, dramatic clarity, and
a satisfying arc. If it is ready, call exit_loop and explain why. Otherwise,
call append_to_state with field 'CRITICAL_FEEDBACK' and give three precise
changes for the next pass.

Research: {RESEARCH?}
Drafts: {PLOT_OUTLINE?}
Earlier feedback: {CRITICAL_FEEDBACK?}
""",
    tools=[append_to_state, exit_loop],
    generate_content_config=types.GenerateContentConfig(temperature=0),
    before_model_callback=log_query_to_model,
    after_model_callback=log_model_response,
)

writers_room = LoopAgent(
    name="writers_room",
    description="Iterates through research, drafting, and critique.",
    sub_agents=[researcher, screenwriter, critic],
    max_iterations=int(os.getenv("MAX_WRITING_ITERATIONS", "3")),
)

box_office_researcher = Agent(
    name="box_office_researcher",
    model=build_model(),
    description="Creates a concise audience and comparable-film analysis.",
    instruction="""
Using the newest PLOT_OUTLINE, identify the likely audience, release positioning,
and two comparable films. Clearly label assumptions. Return a short market note.

Drafts: {PLOT_OUTLINE?}
""",
    output_key="BOX_OFFICE_NOTES",
    generate_content_config=types.GenerateContentConfig(temperature=0.2),
)

casting_agent = Agent(
    name="casting_agent",
    model=build_model(),
    description="Suggests casting profiles for the central roles.",
    instruction="""
Using the newest PLOT_OUTLINE, name the main roles and describe the qualities
needed from each performer. You may suggest example actors, but keep the focus
on role fit. Return a concise casting note.

Drafts: {PLOT_OUTLINE?}
""",
    output_key="CASTING_NOTES",
    generate_content_config=types.GenerateContentConfig(temperature=0.5),
)

preproduction_team = ParallelAgent(
    name="preproduction_team",
    description="Runs market analysis and casting exploration concurrently.",
    sub_agents=[box_office_researcher, casting_agent],
)

file_writer = Agent(
    name="file_writer",
    model=build_model(),
    description="Combines the workflow outputs and saves the final movie pitch.",
    instruction="""
Create a marketable title and a polished pitch containing the logline, synopsis,
three-act outline, market note, and casting note. Call write_movie_pitch with a
short title as filename and the complete pitch as content. Then report the saved
relative path.

Drafts: {PLOT_OUTLINE?}
Market note: {BOX_OFFICE_NOTES?}
Casting note: {CASTING_NOTES?}
""",
    tools=[write_movie_pitch],
    generate_content_config=types.GenerateContentConfig(temperature=0),
)

film_concept_team = SequentialAgent(
    name="film_concept_team",
    description="Develops, evaluates, packages, and saves a historical movie pitch.",
    sub_agents=[writers_room, preproduction_team, file_writer],
)

root_agent = Agent(
    name="greeter",
    model=build_model(),
    description="Starts the movie-pitch workflow.",
    instruction="""
Tell the user you can develop a movie pitch about a historical figure. Ask for
the person's name and any desired tone. Once supplied, call append_to_state with
field 'PROMPT', then transfer to film_concept_team.
""",
    tools=[append_to_state],
    sub_agents=[film_concept_team],
    generate_content_config=types.GenerateContentConfig(temperature=0),
)

quota_plugin = Graceful429Plugin(
    name="graceful_429_plugin",
    fallback_text={
        "default": (
            "The model quota is temporarily exhausted. Your session state is "
            "preserved; wait briefly and retry the last step."
        )
    },
)

app = App(
    name="workflow_agents",
    root_agent=root_agent,
    plugins=[quota_plugin],
)

